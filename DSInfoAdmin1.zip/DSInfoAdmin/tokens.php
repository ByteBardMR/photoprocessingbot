<?php
require_once('includes/db.php');

session_start();

// Проверка наличия сессии и правил доступа
if (!isset($_SESSION['login']) || !isset($_SESSION['rules'])) {
    header("Location: login.php");
    exit();
}

$user_login = $_SESSION['login'];

// Определение роли пользователя на основе правил доступа
switch ($_SESSION['rules']) {
    case 0:
        $user_rules = 'reader';
        break;
    case 1:
        $user_rules = 'editor';
        break;
    case 2:
        $user_rules = 'admin';
        break;
    default:
		$user_rules = 'guest';
		break;
}

// Запрос для получения общего количества записей
$countQuery = "SELECT COUNT(*) AS total FROM tokens";
$countResult = mysqli_query($connection, $countQuery);
$total_results = mysqli_fetch_assoc($countResult)['total'];

// Пагинация
$current_page = isset($_GET['page']) ? $_GET['page'] : 1;
$results_per_page = 10;
$offset = ($current_page - 1) * $results_per_page;
// Модифицированный запрос для получения информации о токенах и пользователях
$selectQuery = "SELECT t.*, u.user_id, u.user_name FROM tokens t LEFT JOIN users u ON t.token = u.token ORDER BY t.created_at DESC LIMIT ? OFFSET ?";
$statement = mysqli_prepare($connection, $selectQuery);
mysqli_stmt_bind_param($statement, 'ii', $results_per_page, $offset);
mysqli_stmt_execute($statement);
$resultSet = mysqli_stmt_get_result($statement);

?>


<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title><?php echo $siteSettings['title']; ?></title>
	<link rel="stylesheet" href="styles/tokens.css?v=<?php echo time(); ?>">
</head>
<body>
	<header>
		<div class="header-content">
			<div class="branding">
				<a id="login-form" class="branding-lnk" href="<?php echo $siteSettings['index']; ?>" title="Главная страница">Dream Singles</a>
			</div>
			<div class="site-info">
				<div class="site-name">
					<p>Web Manager</p>
				</div>

				<div class="user-details">
					<div class="user-greeting">
						<p>
							Hello, <span style="color: #333333;"><?php echo $user_login;?></span> (<?php echo $user_rules;?>)
						</p>
					</div>
					<div class="logout-wrapper">
						<a class="logout-lnk" href="<?php echo $siteSettings['logout']; ?>" title="Выход из системы">Logout</a>
					</div>
				</div>
			</div>
		</div>
	</header>

	<main class="main-section">
		<nav class="nav-bar">
			<ul class="menu">
				<?php foreach ($menuItem as $key => $value): ?>
					<?php if ($_SESSION['rules'] == 0 && in_array($key, ['Users', 'Tokens', 'Add Token', 'Delete Token'])) continue; ?>
					<?php if ($_SESSION['rules'] == 1 && in_array($key, ['Users'])) continue; ?>
					<?php $class = ($_SERVER['PHP_SELF'] == $value) ? 'active-menu-item' : ''; ?>
					<li class="menuItem <?= $class ?>"><a href="<?= $value ?>"><?= $key ?></a></li>
				<?php endforeach; ?>
			</ul>
		</nav>
		<div class="content-container">
			<div class="inner-content">
			<div class="content-row row-info">
				<div class="content-row-left">
					<p>Token</p>
				</div>
				<div class="content-row-center1">
					<p>Is Active</p>
				</div>
				<div class="content-row-center2">
					<p>Created At</p>
				</div>
				<div class="content-row-center3">
					<p>User ID</p>
				</div>
				<div class="content-row-center4">
					<p>User Name</p>
				</div>
				<div class="content-row-right">
					<p>Expires At</p>
				</div>
			</div>
			<?php while ($row = mysqli_fetch_assoc($resultSet)): ?>
				<div class="content-row row-item">
					<div class="content-row-left">
						<a class="editLink" href="<?= $menuItem['Delete Token'] ?>?token=<?= htmlspecialchars($row['token'] ?? ''); ?>" style="color: red;"><?= htmlspecialchars($row['token'] ?? ''); ?></a>
					</div>
					<div class="content-row-center1">
						<a class="editLink" href="<?= $menuItem['Edit Entry'] ?>?token=<?= htmlspecialchars($row['token'] ?? ''); ?>" style="color: orange;"><?= htmlspecialchars($row['is_active'] ?? ''); ?></a>
					</div>
					<div class="content-row-center2">
						<?= htmlspecialchars($row['created_at'] ?? ''); ?>
					</div>
					<div class="content-row-center3">
						<?= htmlspecialchars($row['user_id'] ?? 'N/A'); ?>
					</div>
					<div class="content-row-center4">
						<?= htmlspecialchars($row['user_name'] ?? 'N/A'); ?>
					</div>
					<div class="content-row-right">
						<?= htmlspecialchars($row['expires_at'] ?? ''); ?>
					</div>
				</div>
			<?php endwhile; ?>
			</div>
			<!-- Добавление ссылок для навигации -->
			<div class="pagination-wrapper">
				<div class="pagination">
					<?php 
					$total_pages = ceil($total_results / $results_per_page);
					// Вычисляем номер последней страницы, которая будет отображаться перед текущей страницей
					$last_displayed_page = min($total_pages, max(5, $current_page + 4));
					
					// Если текущая страница больше 5, добавляем стрелку влево
					if ($current_page > 1) {
						echo '<a href="?page=' . ($current_page - 1) . '">&lt;</a>';
					}

					// Выводим ссылки на страницы от первой до последней отображаемой
					for ($i = max(1, $last_displayed_page - 4); $i <= $last_displayed_page; $i++) {
						$class = ($current_page == $i) ? 'active' : '';
						echo '<a class="' . $class . '" href="?page=' . $i . '">' . $i . '</a>';
					}

					// Если последняя отображаемая страница меньше общего количества страниц, добавляем стрелку вправо
					if ($last_displayed_page < $total_pages) {
						echo '<a href="?page=' . ($last_displayed_page + 1) . '">&gt;</a>';
					}
					?>
				</div>
				<div class="total-count">
					<p><?php echo $total_results  . ' Items'?></p>
				</div>
			</div>
		</div>
	</main>


	<script>
		function confirmDelete(id) {
			var confirmation = confirm("Are you sure you want to delete this entry?");
			
			if (confirmation) {
				var xhr = new XMLHttpRequest();
				
				xhr.open("POST", "scripts/delete_entry.php", true);
				xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
				xhr.send("id=" + id);
				
				xhr.onreadystatechange = function() {
					if (xhr.readyState == 4 && xhr.status == 200) {
						alert(xhr.responseText);
						// Перезагрузить текущую страницу
						window.location.reload();
					}
				};
			} else {
				return false;
			}
		}
	</script>
	<script>
		window.addEventListener('DOMContentLoaded', function() {
		var navHeight = document.querySelector('.content-container').offsetHeight;
			document.querySelector('.nav-bar').style.height = navHeight + 'px';
		});
	</script>
</body>
</html>