<?php
// Подключение к базе данных
require_once('../includes/db.php');

// Проверка, был ли получен POST-запрос с параметром id
if(isset($_POST['token'])) {
    // Получение id из POST-параметра
    $token = $_POST['token'];

    // Подготовка запроса для удаления записи с указанным id
    $deleteQuery = "DELETE FROM tokens WHERE token = ?";
    $deleteStmt = mysqli_prepare($connection, $deleteQuery);
    mysqli_stmt_bind_param($deleteStmt, "s", $token);
    mysqli_stmt_execute($deleteStmt);

    // Проверка, была ли успешно удалена запись
    if(mysqli_stmt_affected_rows($deleteStmt) > 0) {
        echo "Entry with ID $token successfully deleted.";
    } else {
        echo "No entry found with ID $token.";
    }

    // Закрыть запрос
    mysqli_stmt_close($deleteStmt);
} else {
    // Если id не был передан, вернуть сообщение об ошибке
    echo "Error: token not provided.";
}