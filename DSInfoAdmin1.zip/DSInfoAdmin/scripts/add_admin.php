<?php
require_once('../includes/db.php');

// Проверка наличия данных в запросе
if (isset($_POST['login']) && isset($_POST['password']) && isset($_POST['rules'])) {
    // Получение данных из запроса
    $login = mysqli_real_escape_string($connection, $_POST['login']);
    $password = mysqli_real_escape_string($connection, $_POST['password']);
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT); // Хеширование пароля
    $rules = intval($_POST['rules']);

    // Проверка наличия такого же логина в базе данных
    $checkQuery = "SELECT * FROM users_table WHERE login = ?";
    $checkStmt = mysqli_prepare($connection, $checkQuery);
    mysqli_stmt_bind_param($checkStmt, "s", $login);
    mysqli_stmt_execute($checkStmt);
    $result = mysqli_stmt_get_result($checkStmt);

    // Проверка результата запроса
    if (mysqli_num_rows($result) > 0) {
        // Логин уже существует, выводим ошибку
        echo "Error: This login already exists.";
    } else {
        // Логин не существует, добавляем нового пользователя
        $insertQuery = "INSERT INTO users_table (login, password, rules) VALUES (?, ?, ?)";
        $insertStmt = mysqli_prepare($connection, $insertQuery);
        mysqli_stmt_bind_param($insertStmt, "ssi", $login, $hashedPassword, $rules);
        mysqli_stmt_execute($insertStmt);
        echo "New admin added successfully.";
    }

    // Закрываем запросы
    mysqli_stmt_close($checkStmt);
    if (isset($insertStmt)) {
        mysqli_stmt_close($insertStmt);
    }
} else {
    // Ошибка: данные не были отправлены
    echo "Error: Data not received.";
}