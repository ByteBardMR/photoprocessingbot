<?php
require_once('../includes/db.php');

// Проверка наличия данных в запросе
if (isset($_POST['action'])) {
    function generateUUIDv4() {
        // Генерация UUID v4 согласно RFC 4122
        return sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
            mt_rand(0, 0xffff), mt_rand(0, 0xffff),
            mt_rand(0, 0xffff),
            mt_rand(0, 0x0fff) | 0x4000,
            mt_rand(0, 0x3fff) | 0x8000,
            mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
        );
    }

    // Генерация нового UUID
    $uuid = generateUUIDv4();

    // Подготовка запроса на вставку
    $query = "INSERT INTO tokens (token) VALUES (?)";
    $stmt = mysqli_prepare($connection, $query);

    // Проверка на успешность подготовки запроса
    if ($stmt === false) {
        die('Prepare failed: ' . mysqli_error($connection));
    }

    // Привязка параметров и выполнение запроса
    mysqli_stmt_bind_param($stmt, 's', $uuid);
    $success = mysqli_stmt_execute($stmt);

    if ($success) {
        echo "Новый UUID успешно добавлен в базу данных: " . $uuid;
    } else {
        echo "Ошибка при добавлении UUID: " . mysqli_stmt_error($stmt);
    }

    // Закрытие запроса
    mysqli_stmt_close($stmt);
} else {
    // Ошибка: данные не были отправлены
    echo "Error: Data not received.";
}