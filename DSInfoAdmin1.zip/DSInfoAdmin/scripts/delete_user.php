<?php
// Подключение к базе данных
require_once('../includes/db.php');

// Проверка, был ли получен POST-запрос с параметром id
if(isset($_POST['id'])) {
    // Получение id из POST-параметра
    $id = intval($_POST['id']);

    // Подготовка запроса для удаления записи с указанным id
    $deleteQuery = "DELETE FROM users_table WHERE id = ?";
    $deleteStmt = mysqli_prepare($connection, $deleteQuery);
    mysqli_stmt_bind_param($deleteStmt, "i", $id);
    mysqli_stmt_execute($deleteStmt);

    // Проверка, была ли успешно удалена запись
    if(mysqli_stmt_affected_rows($deleteStmt) > 0) {
        echo "Entry with ID $id successfully deleted.";
    } else {
        echo "No entry found with ID $id.";
    }

    // Закрыть запрос
    mysqli_stmt_close($deleteStmt);
} else {
    // Если id не был передан, вернуть сообщение об ошибке
    echo "Error: ID not provided.";
}