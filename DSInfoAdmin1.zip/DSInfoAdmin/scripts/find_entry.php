<?php
// Подключение к базе данных
require_once('../includes/db.php');

require_once('includes/start_session.php');

// Проверка токена CSRF при обработке запроса
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['csrf_token']) && $_POST['csrf_token'] === $_SESSION['csrf_token']) {
    // Проверка наличия и корректности ID
    if (isset($_POST['id']) && preg_match('/^\d+$/', $_POST['id'])) {
        $id = intval($_POST['id']); // Преобразуем ID в целое число
        // Запрос к базе данных для получения элементов с указанным id
        $selectQuery = "SELECT * FROM profile_info_table WHERE profile_id = ?";
        $selectStmt = mysqli_prepare($connection, $selectQuery);
        mysqli_stmt_bind_param($selectStmt, "i", $id);
        mysqli_stmt_execute($selectStmt);
        $resultSet = mysqli_stmt_get_result($selectStmt);
    
        // Закрываем запрос
        mysqli_stmt_close($selectStmt);
        echo "ID: " . $id . " успешно обработан";
    } else {
        // Ошибка в ID
        http_response_code(400); // Некорректный запрос
        exit('Ошибка в ID');
    }
} else {
    // Ошибка CSRF
    http_response_code(403); // Запрещенный доступ
    exit('Ошибка CSRF');
}