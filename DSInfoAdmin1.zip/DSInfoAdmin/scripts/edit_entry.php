<?php
// Разрешаем доступ из любого источника
header("Access-Control-Allow-Origin: *");

require_once('../includes/db.php');

if (isset($_POST['token']) && isset($_POST['is_active'])) {
    $token = $_POST['token'];
    $isActive = filter_var($_POST['is_active'], FILTER_VALIDATE_BOOLEAN); // Преобразование в boolean

    // Подготовка запроса на обновление
    $updateQuery = "UPDATE tokens SET is_active = ? WHERE token = ?";
    $stmt = mysqli_prepare($connection, $updateQuery);
    mysqli_stmt_bind_param($stmt, "is", $isActive, $token);
    $result = mysqli_stmt_execute($stmt);

    if ($result) {
        echo "Entry updated successfully.";
    } else {
        echo "An error occurred.";
    }

    mysqli_stmt_close($stmt);
} else {
    echo "Error: Required data not provided.";
}