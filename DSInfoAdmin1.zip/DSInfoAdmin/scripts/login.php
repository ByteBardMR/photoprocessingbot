<?
require_once('../includes/db.php');

	// Проверка, был ли отправлен POST запрос
	if ($_SERVER["REQUEST_METHOD"] == "POST") {
		// Проверка, были ли отправлены поля login и password
		if (isset($_POST['login']) && isset($_POST['password'])) {
			// Защита от SQL-инъекций
			$login = mysqli_real_escape_string($connection, $_POST['login']);
			$password = mysqli_real_escape_string($connection, $_POST['password']);
			
			$query = "SELECT * FROM users_table WHERE login = ?";
			$stmt = mysqli_prepare($connection, $query);
			if ($stmt) {
				mysqli_stmt_bind_param($stmt, "s", $login);
				mysqli_stmt_execute($stmt);
				$result = mysqli_stmt_get_result($stmt);
			
				if (mysqli_num_rows($result) == 1) {
					$user = mysqli_fetch_assoc($result);
					// Используйте password_verify для проверки пароля
					if (password_verify($password, $user['password'])) {
						// Успешная авторизация
						$rules = $user['rules'];
			
						session_start();
						$_SESSION['login'] = $login;
						$_SESSION['rules'] = $rules;
			
						header("Location: /index.php");
						exit();
					} else {
						// Неверный пароль
						http_response_code(401);
						echo json_encode(["message" => "Неверный логин или пароль."]);
					}
				} else {
					// Логин не найден
					http_response_code(401);
					echo json_encode(["message" => "Неверный логин или пароль."]);
				}
			
				mysqli_stmt_close($stmt);
			} else {
				http_response_code(400);
				echo json_encode(["message" => "Ошибка запроса."]);
			}
			
		} else {
			http_response_code(400);
			echo json_encode(["message" => "Пожалуйста, заполните все поля."]);
		}
	}