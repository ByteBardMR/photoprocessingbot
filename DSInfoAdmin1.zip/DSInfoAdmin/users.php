<?php
require_once('includes/db.php');

session_start();

// Проверка наличия сессии и правил доступа
if (!isset($_SESSION['login']) || !isset($_SESSION['rules'])) {
    header("Location: login.php");
    exit();
}

$user_login = $_SESSION['login'];

// Определение роли пользователя на основе правил доступа
switch ($_SESSION['rules']) {
    case 0:
        $user_rules = 'reader';
		header("Location: index.php");
        break;
    case 1:
        $user_rules = 'editor';
		header("Location: index.php");
        break;
    case 2:
        $user_rules = 'admin';
        break;
    default:
		$user_rules = 'guest';
		header("Location: index.php");
		break;
}

// Запрос для получения общего количества записей
$countQuery = "SELECT COUNT(*) AS total FROM users_table";
$countResult = mysqli_query($connection, $countQuery);
$total_results = mysqli_fetch_assoc($countResult)['total'];


// Пагинация
$current_page = isset($_GET['page']) ? $_GET['page'] : 1;
$results_per_page = 10;
$offset = ($current_page - 1) * $results_per_page;
$selectQuery = "SELECT * FROM users_table LIMIT ? OFFSET ?";
$statement = mysqli_prepare($connection, $selectQuery);
mysqli_stmt_bind_param($statement, 'ii', $results_per_page, $offset);
mysqli_stmt_execute($statement);
$resultSet = mysqli_stmt_get_result($statement);
?>


<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title><?php echo $siteSettings['title']; ?></title>
	<link rel="stylesheet" href="styles/users.css?v=<?php echo time(); ?>">
</head>
<body>
	<header>
		<div class="header-content">
			<div class="branding">
				<a id="login-form" class="branding-lnk" href="<?php echo $siteSettings['index']; ?>" title="Главная страница">Dream Singles</a>
			</div>
			<div class="site-info">
				<div class="site-name">
					<p>Web Manager</p>
				</div>

				<div class="user-details">
					<div class="user-greeting">
						<p>
							Hello, <span style="color: #333333;"><?php echo $user_login;?></span> (<?php echo $user_rules;?>)
						</p>
					</div>
					<div class="logout-wrapper">
						<a class="logout-lnk" href="<?php echo $siteSettings['logout']; ?>" title="Выход из системы">Logout</a>
					</div>
				</div>
			</div>
		</div>
	</header>

	<main class="main-section">
		<nav class="nav-bar">
			<ul class="menu">
				<?php foreach ($menuItem as $key => $value): ?>
					<?php if ($_SESSION['rules'] == 0 && in_array($key, ['Users', 'Edit Entry', 'Delete Entry', 'Add Entry'])) continue; ?>
					<?php if ($_SESSION['rules'] == 1 && in_array($key, ['Users'])) continue; ?>
					<?php $class = ($_SERVER['PHP_SELF'] == $value) ? 'active-menu-item' : ''; ?>
					<li class="menuItem <?= $class ?>"><a href="<?= $value ?>"><?= $key ?></a></li>
				<?php endforeach; ?>
			</ul>
		</nav>
		<div class="content-container">

			<div class="form-container">
				<form class="login-form" action="scripts/add_admin.php" method="post">
					<div class="form-column first-column">
						<div class="form-row form-row-left"></div>
						<div class="form-row form-row-right">
							<h1 class="form-label-h1">Add admin</h1>
						</div>
					</div>
					<div class="form-column second-column">
						<div class="form-row form-row-left">
							<p class="form-label">Username</p>
						</div>
						<div class="form-row form-row-right">
							<input id="userLogin" type="text" name="login" class="form-field">
						</div>
					</div>
					<div class="form-column third-column">
						<div class="form-row form-row-left">
							<p class="form-label">Password</p>
						</div>
						<div class="form-row form-row-right form-row-password">
							<input id="userPassword" type="password" name="password" class="form-field">
						</div>
					</div>
					<div class="form-column third-column">
						<div class="form-row form-row-left">
							<p class="form-label">Rules</p>
						</div>
						<div class="form-row form-row-right form-row-password">
							<select id="userRules" name="rules" class="form-field rules-select">
								<option value="0">reader</option>
								<option value="1">editor</option>
								<option value="2">admin</option>
							</select>
						</div>
					</div>
					<div class="form-column fourth-column">
						<div class="form-row form-row-left"></div>
						<div class="form-row form-row-right">
							<input type="submit" style="display: none;">
							<a class="login-btn gradient" onclick="submitForm()">Add</a>
						</div>
					</div>
				</form>
			</div>


			<div class="inner-content">
				<div class="content-row row-info">
					<div class="content-row-left">
						<p>Login</p>
					</div>
					<div class="content-row-center">
						<p>Rules</p>
					</div>
					<div class="content-row-right">
						<p>Action</p>
					</div>
				</div>

				
				<?php while ($row = mysqli_fetch_assoc($resultSet)) {
					switch ($row['rules']) {
						case 0:
							$rules_info = 'reader';
							break;
						case 1:
							$rules_info = 'editor';
							break;
						case 2:
							$rules_info = 'admin';
							break;
					}
					echo '<div class="content-row row-item">';
					echo '<div class="content-row-left">';
					echo '<p>' . $row['login'] . '</p>';
					echo '</div>';
					echo '<div class="content-row-center">';
					echo '<p>' . $rules_info . '</p>';
					echo '</div>';
					echo '<div class="content-row-right">';
					echo '<div class="content-row-actions hidden">';
					echo '<div>';
					echo '<a class="deleteLink tableLink" href="" id="deleteEntryBtn" onclick="return confirmDelete(' . $row['id'] . ')" style="color: red">Delete</a>';
					echo '</div>';
					echo '</div>';
					echo '</div>';
					echo '</div>';
				}
				?>
			</div>
			<!-- Добавление ссылок для навигации -->
			<div class="pagination-wrapper">
				<div class="pagination">
					<?php 
					$total_pages = ceil($total_results / $results_per_page);
					// Вычисляем номер последней страницы, которая будет отображаться перед текущей страницей
					$last_displayed_page = min($total_pages, max(5, $current_page + 4));
					
					// Если текущая страница больше 5, добавляем стрелку влево
					if ($current_page > 1) {
						echo '<a href="?page=' . ($current_page - 1) . '">&lt;</a>';
					}

					// Выводим ссылки на страницы от первой до последней отображаемой
					for ($i = max(1, $last_displayed_page - 4); $i <= $last_displayed_page; $i++) {
						$class = ($current_page == $i) ? 'active' : '';
						echo '<a class="' . $class . '" href="?page=' . $i . '">' . $i . '</a>';
					}

					// Если последняя отображаемая страница меньше общего количества страниц, добавляем стрелку вправо
					if ($last_displayed_page < $total_pages) {
						echo '<a href="?page=' . ($last_displayed_page + 1) . '">&gt;</a>';
					}
					?>
				</div>
				<div class="total-count">
					<p><?php echo $total_results  . ' Items'?></p>
				</div>
			</div>
		</div>
	</main>


	<script>
		function submitForm() {
			// Получение значений из полей формы
			var userLogin = document.getElementById("userLogin").value;
			var userPassword = document.getElementById("userPassword").value;
			var userRules = document.getElementById("userRules").value;
			
			// Проверка на пустые поля
			if (userLogin.trim() === "" || userPassword.trim() === "") {
				alert("Please fill in all fields.");
				return;
			}
			
			// Проверка длины пароля
			if (userPassword.length < 8) {
				alert("Password should be at least 8 characters long.");
				return;
			}
			
			// Создание объекта FormData для отправки данных формы
			var formData = new FormData();
			formData.append('login', userLogin);
			formData.append('password', userPassword);
			formData.append('rules', userRules);

			// Создание объекта XMLHttpRequest
			var xhr = new XMLHttpRequest();
			xhr.open("POST", "scripts/add_admin.php", true);
			
			// Обработка ответа сервера
			xhr.onload = function() {
				if (xhr.status === 200) {
					// Обработка успешного ответа
					alert(xhr.responseText); // Вывод ответа от сервера
					// Очистка полей формы после успешной отправки
					document.getElementById("userLogin").value = "";
					document.getElementById("userPassword").value = "";
					document.getElementById("userRules").value = "0"; // Возврат к начальному значению
					window.location.reload();
				} else {
					// Обработка ошибки
					alert("Error: " + xhr.status); // Вывод статуса ошибки
				}
			};

			// Отправка данных формы на сервер
			xhr.send(formData);
		}
	</script>

	<script>
		function confirmDelete(id) {
			var confirmation = confirm("Are you sure you want to delete this entry?");
			
			if (confirmation) {
				var xhr = new XMLHttpRequest();
				
				xhr.open("POST", "scripts/delete_user.php", true);
				xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
				xhr.send("id=" + id);
				
				xhr.onreadystatechange = function() {
					if (xhr.readyState == 4 && xhr.status == 200) {
						alert(xhr.responseText);
						// Перезагрузить текущую страницу
						window.location.reload();
					}
				};
			} else {
				return false;
			}
		}
	</script>
	<script>
		window.addEventListener('DOMContentLoaded', function() {
		var navHeight = document.querySelector('.content-container').offsetHeight;
			document.querySelector('.nav-bar').style.height = navHeight + 'px';
		});
	</script>
</body>
</html>