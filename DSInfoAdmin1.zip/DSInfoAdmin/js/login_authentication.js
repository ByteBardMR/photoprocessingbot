document.getElementById("loginBtn").addEventListener("click", function(event) {
    event.preventDefault(); // Предотвращаем стандартное поведение кнопки

    function manageStyle(action) {
        var formRowPassword = document.querySelector(".form-row-password");
        var authErrorLabel = document.getElementById("authErrorLabel");
    
        if (action === 'add') {
            formRowPassword.style.marginBottom = "20px";
            authErrorLabel.style.marginTop = "5px";
        } else if (action === 'remove') {
            formRowPassword.style.marginBottom = "0";
            authErrorLabel.style.marginTop = "0";
        }
    }

    // Удаление классов ошибки
    document.querySelectorAll(".user-login-input, .user-password-input").forEach(function(element) {
        element.classList.remove("error-field");
    });

    manageStyle('remove');

    var login = document.getElementById("userLogin").value.trim();
    var password = document.getElementById("userPassword").value.trim();

    // Проверка на пустые значения
    if (login === '' || password === '') {
        var authErrorLabel = document.getElementById("authErrorLabel");
        authErrorLabel.innerHTML = "Fill in all fields";
        authErrorLabel.classList.remove("hidden");
        manageStyle('add');

        // Добавление класса ошибки к пустым полям
        if (login === '') {
            document.querySelector(".user-login-input").classList.add("error-field");
        }
        if (password === '') {
            document.querySelector(".user-password-input").classList.add("error-field");
        }
        return;
    }

    var formData = new FormData();
    formData.append("login", login);
    formData.append("password", password);

    var xhr = new XMLHttpRequest();
    xhr.open("POST", "scripts/login.php", true);

    xhr.onload = function() {
        if (xhr.status >= 200 && xhr.status < 300) {
            var response = JSON.parse(xhr.responseText);
            if (response.status === "success") {
                window.location.href = "index.php";
            } else {
                // Сюда код попадать не должен, если сервер всегда возвращает 200 для успеха
                showError("Неизвестная ошибка, попробуйте ещё раз.");
            }
        } else {
            // Обработка ошибочных статусов, таких как 400 или 500
            try {
                var response = JSON.parse(xhr.responseText);
                showError(response.message || "Ошибка на сервере.");
            } catch (error) {
                // Если ответ от сервера не является валидным JSON
                showError("Ошибка при обработке ответа сервера.");
            }
        }
    };
    
    xhr.onerror = function() {
        console.error("Ошибка при отправке запроса");
        var authErrorLabel = document.getElementById("authErrorLabel");
        authErrorLabel.innerHTML = "Ошибка при отправке запроса.";
        authErrorLabel.classList.remove("hidden");
        manageStyle('add');
    };

    function showError(message) {
        var authErrorLabel = document.getElementById("authErrorLabel");
        authErrorLabel.innerHTML = "message";
        authErrorLabel.classList.remove("hidden");
        manageStyle('add');
    }

    xhr.send(formData);
});