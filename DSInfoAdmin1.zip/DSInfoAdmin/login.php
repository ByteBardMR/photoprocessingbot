<?php
require_once('includes/db.php');

session_start();

$hidden_element = '';
// Проверка наличия сессии и правил доступа
if (isset($_SESSION['login']) || isset($_SESSION['rules'])) {
    header("Location: index.php");
    exit();
} else {
	$user_rules = 'guest';
	$user_login = 'guest';
	$hidden_element = 'hidden';
}



?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title><?php echo $siteSettings['title']; ?></title>
	<link rel="stylesheet" href="styles/login.css?v=<?php echo time(); ?>">

</head>
<body>
	<header>
		<div class="header-content">
			<div class="branding">
				<a id="login-form" class="branding-lnk" href="<?php echo $siteSettings['index']; ?>" title="Главная страница">Dream Singles</a>
			</div>
			<div class="site-info">
				<div class="site-name">
					<p>Web Manager</p>
				</div>

				<div class="user-details <?php echo $hidden_element;?>">
					<div class="user-greeting">
						<p>
							Hello, <span style="color: #333333;"><?php echo $user_login;?></span> (<?php echo $user_rules;?>)
						</p>
					</div>
					<div class="logout-wrapper">
						<a class="logout-lnk" href="<?php echo $siteSettings['logout']; ?>" title="Выход из системы">Logout</a>
					</div>
				</div>
			</div>
		</div>
	</header>

	<main>
		<div class="form-container">
			<form class="login-form" action="login.php" method="post">
				<div class="form-column first-column">
					<div class="form-row form-row-left"></div>
					<div class="form-row form-row-right">
						<h1 class="form-label-h1">Login</h1>
					</div>
				</div>
				<div class="form-column second-column">
					<div class="form-row form-row-left">
						<p class="form-label">Username</p>
					</div>
					<div class="form-row form-row-right">
						<input id="userLogin" type="text" name="login" class="form-field">
					</div>
				</div>
				<div class="form-column third-column">
					<div class="form-row form-row-left">
						<p class="form-label">Password</p>
					</div>
					<div class="form-row form-row-right form-row-password">
						<input id="userPassword" type="password" name="password" class="form-field">
						<label id="authErrorLabel" class="error hidden">Wrong login or password</label>
					</div>
				</div>
				<div class="form-column fourth-column">
					<div class="form-row form-row-left"></div>
					<div class="form-row form-row-right">
						<input type="submit" style="display: none;">
						<a class="login-btn gradient" onclick="submitForm()">Log in</a>
					</div>
				</div>
			</form>
		</div>
	</main>

	<script>
		function submitForm() {
			var login = document.getElementById("userLogin").value;
			var password = document.getElementById("userPassword").value;

			// Проверка на пустые значения
			if (login.trim() === '' || password.trim() === '') {
				console.error("Пожалуйста, заполните все поля.");
				return; // Важно добавить return, чтобы остановить выполнение функции
			}

			var data = "login=" + encodeURIComponent(login) + "&password=" + encodeURIComponent(password);

			var xhr = new XMLHttpRequest();
			xhr.open("POST", "scripts/login.php", true);
			xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
			xhr.send(data);

			xhr.onload = function() {
				if (xhr.status === 200) {
					window.location.href = "index.php";
				} else {
					// Ошибка при отправке запроса
					console.error("Ошибка при отправке запроса");

					// Добавление стиля margin-bottom: 20px к элементу с классом form-row-password
					var formRowPassword = document.querySelector(".form-row-password");
					formRowPassword.style.marginBottom = "20px";

					// Добавление класса error-field к элементу с id userPassword
					var userPassword = document.getElementById("userPassword");
					userPassword.classList.add("error-field");

					// Удаление класса hidden у элемента с id authErrorLabel
					var authErrorLabel = document.getElementById("authErrorLabel");
					var response = JSON.parse(xhr.responseText);
					authErrorLabel.innerHTML = response.message;
					authErrorLabel.classList.remove("hidden");
				}
			};
		}
	</script>
</body>
</html>