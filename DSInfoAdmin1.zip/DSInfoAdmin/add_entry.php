<?php
require_once('includes/db.php');

session_start();

// Проверка наличия сессии и правил доступа
if (!isset($_SESSION['login']) || !isset($_SESSION['rules'])) {
    header("Location: login.php");
    exit();
}

$user_login = $_SESSION['login'];

// Определение роли пользователя на основе правил доступа
switch ($_SESSION['rules']) {
    case 0:
        $user_rules = 'reader';
		header("Location: index.php");
        break;
    case 1:
        $user_rules = 'editor';
        break;
    case 2:
        $user_rules = 'admin';
        break;
    default:
		$user_rules = 'guest';
		header("Location: index.php");
		break;
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title><?php echo $siteSettings['title']; ?></title>
	<link rel="stylesheet" href="styles/add.css?v=<?php echo time(); ?>">
</head>
<body>
	<header>
		<div class="header-content">
			<div class="branding">
				<a id="login-form" class="branding-lnk" href="<?php echo $siteSettings['index']; ?>" title="Главная страница">Dream Singles</a>
			</div>
			<div class="site-info">
				<div class="site-name">
					<p>Web Manager</p>
				</div>

				<div class="user-details">
					<div class="user-greeting">
						<p>
							Hello, <span style="color: #333333;"><?php echo $user_login;?></span> (<?php echo $user_rules;?>)
						</p>
					</div>
					<div class="logout-wrapper">
						<a class="logout-lnk" href="<?php echo $siteSettings['logout']; ?>" title="Выход из системы">Logout</a>
					</div>
				</div>
			</div>
		</div>
	</header>

	<main class="main-section">
		<nav class="nav-bar">
			<ul class="menu">
				<?php foreach ($menuItem as $key => $value): ?>
					<?php if ($_SESSION['rules'] == 0 && in_array($key, ['Users', 'Tokens', 'Add Token', 'Delete Token'])) continue; ?>
					<?php if ($_SESSION['rules'] == 1 && in_array($key, ['Users'])) continue; ?>
					<?php $class = ($_SERVER['PHP_SELF'] == $value) ? 'active-menu-item' : ''; ?>
					<li class="menuItem <?= $class ?>"><a href="<?= $value ?>"><?= $key ?></a></li>
				<?php endforeach; ?>
			</ul>
		</nav>
		<div class="content-container">
			<div class="inner-content">
                <a href="" id="addNewEntryBtn" class="add-new-entry-button gradient">Add new entry</a>
            </div>
		</div>
	</main>



	<script>
		document.addEventListener("DOMContentLoaded", function() {
            var addNewEntryBtn = document.getElementById("addNewEntryBtn");
            // Отправка данных на сервер по нажатию на кнопку
            addNewEntryBtn.addEventListener('click', function(event) {
                // Предотвращаем отправку формы по умолчанию
                event.preventDefault();

                // Получаем значения из текстовых полей
                var action = 'add';

				if (action == 'add') {
					// Создаем новый XMLHttpRequest объект
					var xhr = new XMLHttpRequest();
					
					// Устанавливаем метод и URL для запроса
					xhr.open("POST", "scripts/add_entry.php", true);
					xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
					// Функция, которая будет вызвана при получении ответа от сервера
					xhr.onload = function() {
						if (xhr.status === 200) {
							// Выводим ответ от сервера в диалоговом окне console.log(alert)
							alert((xhr.responseText));
						} else {
							// Выводим сообщение об ошибке, если сервер вернул код ошибки
							alert(("Error: " + xhr.status));
						}
					};

					// Отправляем данные на сервер
					xhr.send("action=" + encodeURIComponent(action));
				} else {
					// Выводим сообщение об ошибке, если infoValue пустое
					alert("Please fill in all fields.");
				}
            });

        });
	</script>
	<script>
		window.addEventListener('DOMContentLoaded', function() {
		var navHeight = document.querySelector('.content-container').offsetHeight;
			document.querySelector('.nav-bar').style.height = navHeight + 'px';
		});
	</script>
</body>
</html>