<?php
    require_once('config.php');

$connection = mysqli_connect($db_connection_data['host'], $db_connection_data['username'], $db_connection_data['password'], $db_connection_data['database'], $db_connection_data['port']);

// Проверка подключения
if (!$connection) {
    die("Ошибка подключения: " . mysqli_connect_error());
}