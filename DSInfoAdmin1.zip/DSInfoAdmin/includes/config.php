<?php
    $db_connection_data = array(
        'host' => 'localhost',
        'port' => '3306',
        'username' => 'imagebot',
        'password' => '13ASEmAg19',
        'database' => 'image_processing_bot'
    );

    $siteSettings = array(
        'title' => 'DS Web Manager',
        'index' => '/index.php',
        'logout' => '/scripts/logout.php',
    );

    $menuItem = array(
        'Users' => '/index.php',
        'Tokens' => '/tokens.php',
        'Add Token' => '/add_entry.php',
        'Delete Token' => '/delete_entry.php',
        'Edit Entry' => '/edit_entry.php',
        'Admins' => '/users.php',
    );