<?php
// Устанавливаем параметры сессии
session_set_cookie_params([
    'httponly' => true,
    'samesite' => 'strict' // Устанавливаем атрибут SameSite в 'strict'
]);

// Устанавливаем время жизни cookie сессии в 3600 секунд (1 час)
ini_set('session.cookie_lifetime', 3600);

// Запускаем сессию
session_start();