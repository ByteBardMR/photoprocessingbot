var inputFolder = "E:/Python Projects/photo-processing-bot/photo-storage/5791722672-13701590664248314/input/";
var outputFolder = "E:/Python Projects/photo-processing-bot/photo-storage/5791722672-13701590664248314/output/";




// Функция для обработки каждой фотографии
function processPhoto(inputFile) {
    try {
        // Открываем входной файл
        var inputFileRef = new File(inputFile);
        var doc = app.open(inputFileRef);

        // Запускаем записанную операцию NeuralDreamFace
        var result = app.doAction("MK-1", "MK-1"); // Предполагается, что операция записана именно под этим именем

        // Сохраняем обработанное изображение в указанную папку с тем же именем файла и расширением
        var outputFile = new File(outputFolder + inputFileRef.name);
        var options = new ExportOptionsSaveForWeb();
        options.format = SaveDocumentType.JPEG;
        options.quality = 100;
        doc.exportDocument(outputFile, ExportType.SAVEFORWEB, options);

        // Закрываем текущий документ без сохранения изменений
        doc.close(SaveOptions.DONOTSAVECHANGES);
        return true;
    } catch (e) {
        // Обработка ошибок
        $.writeln("Error processing file: " + inputFile + "\n" + e); // Информация об отсутствии файлов для обработки
        var errorFile = new File(outputFolder + "error.txt");
        errorFile.open("w");
        errorFile.writeln("Error processing file: " + inputFile + "\n" + e);
        errorFile.close();
        return false;
    }
}

// Получаем список файлов каждого формата по очереди и обрабатываем их
var inputFiles = [];
var fileExtensions = ["jpeg", "jpg", "png"];

for (var j = 0; j < fileExtensions.length; j++) {
    var currentExtension = fileExtensions[j];
    var filesWithExtension = Folder(inputFolder).getFiles("*." + currentExtension);
    for (var k = 0; k < filesWithExtension.length; k++) {
        inputFiles.push(filesWithExtension[k]);
    }
}

if (inputFiles.length > 0) { // Проверяем, есть ли файлы в папке
    for (var i = 0; i < inputFiles.length; i++) {
        var inputFile = inputFiles[i];
        processPhoto(inputFile);
    }

    // Создаем текстовый файл с названием "done" в папке output
    var doneFile = new File(outputFolder + "done.txt");
    doneFile.open("w");
    doneFile.writeln("Processing completed.");
    doneFile.close();

} else {
    $.writeln("No files to process in inputFolder."); // Информация об отсутствии файлов для обработки
    var errorFile = new File(outputFolder + "error.txt");
    errorFile.open("w");
    errorFile.writeln("No files to process in inputFolder.");
    errorFile.close();
}
