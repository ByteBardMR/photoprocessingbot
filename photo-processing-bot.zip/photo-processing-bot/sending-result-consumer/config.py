from dotenv import load_dotenv
import os

load_dotenv()

class Config:
    TOKEN = os.getenv('TOKEN')
    RABBITMQ_SERVER = os.getenv('RABBITMQ_SERVER')
    PHOTO_STORAGE_DIR = '/app/photo-storage/'