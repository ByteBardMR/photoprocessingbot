import json
import os
import pika
import telebot
import shutil
from config import Config

# Инициализация бота
bot = telebot.TeleBot(Config.TOKEN)

def send_files_to_user(user_id, files):
    for file in files:
        try:
            with open(file, 'rb') as f:
                bot.send_document(user_id, f)
            os.remove(file)  # Удаляем файл после отправки
        except Exception as e:
            print(f"Error sending file {file}: {e}")

def callback(ch, method, properties, body):
    message = json.loads(body.decode('utf-8'))
    output_folder = message.get('outputFolder')
    if output_folder.endswith('output/'):
        delete_output_folder = output_folder[:-len('output/')]

    user_id = message.get('userId')

    if output_folder and user_id:
        files = [os.path.join(output_folder, f) for f in os.listdir(output_folder) if f.lower().endswith(('.jpg', '.jpeg', '.png'))]
        send_files_to_user(user_id, files)

        # Удаляем папку после отправки всех файлов
        shutil.rmtree(delete_output_folder, ignore_errors=True)
        ch.basic_ack(delivery_tag=method.delivery_tag)

connection_params = pika.ConnectionParameters(Config.RABBITMQ_SERVER)
connection = pika.BlockingConnection(connection_params)
channel = connection.channel()
channel.queue_declare(queue='photos_queue_output', durable=True)

channel.basic_qos(prefetch_count=1)
channel.basic_consume(queue='photos_queue_output', on_message_callback=callback)

print("Waiting for messages...")
channel.start_consuming()
