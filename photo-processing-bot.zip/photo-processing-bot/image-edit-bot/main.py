import asyncio
import nest_asyncio
from telegram.ext import Application
from config import Config
from handlers import setup_conv_handler
from log_config import setup_logging
from dbpool import create_pool

nest_asyncio.apply()

async def main():
    await create_pool()
    setup_logging()
    application = Application.builder().token(Config.TOKEN).build()

    conv_handler = setup_conv_handler()
    application.add_handler(conv_handler)

    await application.run_polling()

if __name__ == '__main__':
    asyncio.run(main())
