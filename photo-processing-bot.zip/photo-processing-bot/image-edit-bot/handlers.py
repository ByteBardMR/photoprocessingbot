import json
import logging
from collections import defaultdict
from telegram import ReplyKeyboardRemove, Update, ReplyKeyboardMarkup
from telegram.ext import CommandHandler, MessageHandler, ConversationHandler, filters
# rabbitmq.py
from rabbitmq import RabbitMQConnectionPool
# config.py
from config import Config
# utils.py
from utils import create_folders_for_user, save_document
from utils import add_user_and_check_token
from dbpool import get_connection


# Добавляем новое состояние для обработки отмены
QUANTITY_PHOTOS_ACTION, WAITING_PHOTOS_ACTION, AUTHORIZATION = range(3)


error_logger = logging.getLogger('error_logger')
info_logger = logging.getLogger('info_logger')


async def check_authorization(update, context):
    """Проверяет авторизацию пользователя и возвращает статус авторизации."""
    user_id = update.message.from_user.id
    user_username = update.message.from_user.username if update.message.from_user.username else "Неизвестный"
    
    message, is_authorized = await add_user_and_check_token(user_id, user_username)
    if message:
        await update.message.reply_text(message)
    return is_authorized


async def start(update: Update, context) -> int:
    is_authorized = await check_authorization(update, context)
    if not is_authorized:
        return AUTHORIZATION
    
    info_logger.info("Received command /start from user: %s", update.message.from_user.username)

    keyboard = [
        [Config.NUMERIC_KEYPAD[str(i)] for i in range(1, 6)],
        [Config.NUMERIC_KEYPAD[str(i)] for i in range(6, 11)],
    ]

    reply_markup = ReplyKeyboardMarkup(keyboard, resize_keyboard=True)
    await update.message.reply_text("Привет, {}!👋\nЯ - бот для обработки изображений 😇".format(update.message.from_user.first_name))
    await update.message.reply_text("Выберите количество фотографий, которые вы собираетесь отправить:", reply_markup=reply_markup)

    return QUANTITY_PHOTOS_ACTION


async def process_upload_photos(update: Update, context) -> int:
    is_authorized = await check_authorization(update, context)
    if not is_authorized:
        return AUTHORIZATION

    context.user_data['command_text'] = update.effective_message.text
    command_text = context.user_data.get('command_text')

    # Проверяем, совпадает ли command_text с числами из NUMERIC_KEYPAD
    if command_text in Config.NUMERIC_KEYPAD.values():
        context.user_data['photo_quantity'] = update.effective_message.text
        photo_quantity = context.user_data.get('photo_quantity')
        keyboard = [[Config.MENU_BUTTON["CANCEL"]]]
        reply_markup = ReplyKeyboardMarkup(keyboard, resize_keyboard=True)
        await update.message.reply_text(f"Отправьте мне {photo_quantity} фото АЛЬБОМОМ без сжатия, и я начну обрабатывать их!", reply_markup=reply_markup)

        return WAITING_PHOTOS_ACTION
    else:
        return await exception_command(update, context)


media_group_files = defaultdict(list)
async def handle_valid_message(update: Update, context) -> None:
    is_authorized = await check_authorization(update, context)
    if not is_authorized:
        return AUTHORIZATION

    context.user_data['command_text'] = update.effective_message.text
    command_text = context.user_data.get('command_text')
    photo_quantity = context.user_data.get('photo_quantity')
    document = update.effective_message.document
    media_group_id = update.effective_message.media_group_id
    message = update.message

    if command_text == Config.MENU_BUTTON['CANCEL']:
        info_logger.info("Получена команда отмены от пользователя: %s", update.message.from_user.username)
        return await cancel(update, context)
    else:
        if message.photo:
            return await interruption(update, context)
        elif message.document:
            file_name = document.file_name
            valid_extensions = ['.jpg', '.png', '.jpeg']
            if any(file_name.lower().endswith(ext) for ext in valid_extensions):
                # Добавление имени файла в media_group_files
                if media_group_id is not None:
                    media_group_files[media_group_id].append(document.file_name)
                    if len(media_group_files[media_group_id]) < int(photo_quantity):
                        rest = int(photo_quantity) - len(media_group_files[media_group_id])
                        await update.message.reply_text(f"Ожидание файлов: {rest}")
                        await handle_documents(update, context)
                    elif len(media_group_files[media_group_id]) == int(photo_quantity):
                        await update.message.reply_text(f"Ожидание файлов: 0")
                        await handle_documents(update, context)
                        await perform_required_function(update, context)
                        return await end_processing(update, context)
                    elif len(media_group_files[media_group_id]) > int(photo_quantity):
                        await update.message.reply_text(f"Превышено количество файлов, они будут пропущены")
                else:
                    await handle_documents(update, context)
                    await perform_required_function(update, context)
                    return await end_processing(update, context)
            else:
                await update.message.reply_text("Пожалуйста, отправьте файлы только с расширениями .jpg, .png, .jpeg.")
                return ConversationHandler.END
        else:
            # Если сообщение не содержит ни фотографий, ни документов, обрабатываем как остальные сообщения
            return await interruption(update, context)


async def handle_documents(update: Update, context) -> None:
    try:
        document = update.effective_message.document
        media_group_id = update.effective_message.media_group_id
        user_id = update.message.from_user.id  # Получаем id пользователя
        info_logger.info(f"Обработка документа от пользователя {user_id} с media_group_id: {media_group_id}")

        input_folder_path, output_folder_path = await create_folders_for_user(user_id, media_group_id)

        # Сохраняем документ в папку input
        await save_document(document, input_folder_path)

        # Записываем пути в context.user_data
        context.user_data['input_folder_path'] = input_folder_path
        context.user_data['output_folder_path'] = output_folder_path

    except Exception as e:
        error_logger.error(f"Ошибка при обработке документа: {e}")


# Экземпляр пула соединений
rabbitmq_pool = RabbitMQConnectionPool()
async def perform_required_function(update: Update, context):
    try:
        input_folder_path = context.user_data.get('input_folder_path')
        output_folder_path = context.user_data.get('output_folder_path')
        user_id = update.message.from_user.id
        
        input_folder = input_folder_path.replace("\\", "/") + "/"
        output_folder = output_folder_path.replace("\\", "/") + "/"

        message = json.dumps({'inputFolder': input_folder, 'outputFolder': output_folder, 'userId': str(user_id)})
        
        rabbitmq_pool.publish_message(queue='photos_queue', body=message)
        info_logger.info(f"Сообщение отправлено в очередь RabbitMQ для пользователя {user_id}")

        await update.message.reply_text("Ваши фотографии приняты в обработку. Ожидайте.")

    except Exception as e:
        error_logger.error(f"Ошибка при отправке сообщения в очередь RabbitMQ: {e}")
        await update.message.reply_text("Произошла ошибка при обработке ваших фотографий.")



async def exception_command(update: Update, context) -> int:
    is_authorized = await check_authorization(update, context)
    if not is_authorized:
        return AUTHORIZATION

    keyboard = [
        [Config.NUMERIC_KEYPAD[str(i)] for i in range(1, 6)],
        [Config.NUMERIC_KEYPAD[str(i)] for i in range(6, 11)],
    ]

    reply_markup = ReplyKeyboardMarkup(keyboard, resize_keyboard=True)
    await update.message.reply_text("Выберите количество фотографий, которые вы собираетесь отправить:", reply_markup=reply_markup)

    context.user_data.clear()

    return QUANTITY_PHOTOS_ACTION


async def end_processing(update: Update, context) -> int:
    user = update.message.from_user
    info_logger.info("Конец для пользователя %s возврат состояния.", user.first_name)
    await update.message.reply_text('Введите /start, чтобы начать заново.',reply_markup=ReplyKeyboardRemove())

    # Очищаем данные пользователя
    context.user_data.clear()

    return ConversationHandler.END


async def interruption(update: Update, context) -> int:
    user = update.message.from_user
    info_logger.info("Пользователь %s совершил некорректное дейтсвие.", user.first_name)
    await update.message.reply_text('Некорректное дейтсвие. Введите /start, чтобы начать заново.',reply_markup=ReplyKeyboardRemove())

    # Очищаем данные пользователя
    context.user_data.clear()

    return ConversationHandler.END


async def cancel(update: Update, context) -> int:
    user = update.message.from_user
    info_logger.info("Пользователь %s отменил разговор.", user.first_name)
    await update.message.reply_text('Действие отменено. Введите /start, чтобы начать заново.',reply_markup=ReplyKeyboardRemove())

    # Очищаем данные пользователя
    context.user_data.clear()

    return ConversationHandler.END


async def auth(update: Update, context) -> int:
    user_id = update.message.from_user.id
    args = context.args  # Получаем список аргументов после команды

    if not args:
        await update.message.reply_text("Пожалуйста, укажите токен после команды. Пример: /auth ваш_токен")
        return ConversationHandler.END
    
    token_to_check = args[0]  # Первый аргумент после команды должен быть токеном

    async with get_connection() as conn:
        async with conn.cursor() as cur:
            # Проверяем, существует ли такой токен
            await cur.execute("SELECT token FROM tokens WHERE token = %s AND is_active = 1", (token_to_check,))
            token_exists = await cur.fetchone()

            if not token_exists:
                await update.message.reply_text("Токен ошибочный или неактивен. Пожалуйста, попробуйте снова.")
                return ConversationHandler.END
            
            # Токен существует и активен, обновляем запись пользователя в таблице users
            await cur.execute("UPDATE users SET token = %s WHERE user_id = %s", (token_to_check, user_id,))
            await update.message.reply_text("Авторизация успешна! Теперь вы можете пользоваться функциями бота /start.")
            
    return ConversationHandler.END


def setup_conv_handler():
    return ConversationHandler(
        entry_points=[CommandHandler('start', start)],
        states={
            QUANTITY_PHOTOS_ACTION: [MessageHandler(filters.TEXT & ~filters.COMMAND, process_upload_photos)],
            WAITING_PHOTOS_ACTION: [MessageHandler(filters.ALL, handle_valid_message)],
            AUTHORIZATION: [CommandHandler('auth', auth)]
        },
        fallbacks=[
            CommandHandler('cancel', cancel),
            MessageHandler(filters.TEXT, exception_command)
        ],
    )