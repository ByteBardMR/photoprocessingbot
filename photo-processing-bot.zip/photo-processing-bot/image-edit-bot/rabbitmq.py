import pika
import os
from dotenv import load_dotenv
from multiprocessing.pool import ThreadPool

load_dotenv()

class RabbitMQConnectionPool:
    def __init__(self, host=os.getenv('RABBITMQ_SERVER'), pool_size=5):
        self.host = host
        self.pool = ThreadPool(processes=pool_size)
        self.params = pika.ConnectionParameters(host=self.host)

    def get_connection(self):
        return pika.BlockingConnection(self.params)

    def close(self):
        self.pool.close()
        self.pool.join()

    def publish_message(self, queue, body):
        def publish(conn_params):
            connection = pika.BlockingConnection(conn_params)
            channel = connection.channel()
            channel.queue_declare(queue=queue, durable=True)
            channel.basic_publish(exchange='', routing_key=queue, body=body)
            connection.close()

        self.pool.apply_async(publish, (self.params,))