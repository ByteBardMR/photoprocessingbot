import aiomysql
from contextlib import asynccontextmanager
from dotenv import load_dotenv
import os

# Загружаем переменные окружения
load_dotenv()

# Определение параметров подключения к базе данных из переменных окружения
DB_SETTINGS = {
    "host": os.getenv('DB_HOST'),
    "port": int(os.getenv('DB_PORT')),
    "user": os.getenv('DB_USERNAME'),
    "password": os.getenv('DB_PASSWORD'),
    "db": os.getenv('DB_NAME'),
    "charset": 'utf8mb4',
    "autocommit": True
}

# Глобальный пул подключений
pool = None

async def create_pool():
    global pool
    pool = await aiomysql.create_pool(**DB_SETTINGS)

@asynccontextmanager
async def get_connection():
    global pool
    if pool is None:
        await create_pool()
    async with pool.acquire() as conn:
        yield conn
