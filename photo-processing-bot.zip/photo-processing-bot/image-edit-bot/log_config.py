import logging
from logging.handlers import TimedRotatingFileHandler

def setup_logging():
    log_format = '%(asctime)s - %(levelname)s - %(message)s'
    date_format = '%Y-%m-%d %H:%M:%S'
    formatter = logging.Formatter(log_format, date_format)

    error_handler = TimedRotatingFileHandler('error.log', when='midnight', backupCount=7)
    error_handler.setFormatter(formatter)
    error_handler.setLevel(logging.ERROR)

    info_handler = TimedRotatingFileHandler('info.log', when='midnight', backupCount=7)
    info_handler.setFormatter(formatter)
    info_handler.setLevel(logging.INFO)

    error_logger = logging.getLogger('error_logger')
    error_logger.setLevel(logging.ERROR)
    error_logger.addHandler(error_handler)

    info_logger = logging.getLogger('info_logger')
    info_logger.setLevel(logging.INFO)
    info_logger.addHandler(info_handler)