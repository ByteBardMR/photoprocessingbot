import os
import logging
import datetime
import uuid
# config.py
from config import Config
from dotenv import load_dotenv
from dbpool import get_connection

error_logger = logging.getLogger('error_logger')
info_logger = logging.getLogger('info_logger')

load_dotenv()


async def add_user_and_check_token(user_id: int, user_username: str = None):
    is_authorized = False  # По умолчанию пользователь не авторизован
    async with get_connection() as conn:
        async with conn.cursor() as cur:
            # Проверяем, существует ли пользователь
            await cur.execute("SELECT token FROM users WHERE user_id = %s", (user_id,))
            user = await cur.fetchone()

            if not user:
                # Добавляем нового пользователя, если его нет
                await cur.execute("INSERT INTO users (user_id, user_name) VALUES (%s, %s)", (user_id, user_username,))
                message = 'Пожалуйста, авторизуйтесь при помощи команды /auth.'
            else:
                token = user[0]
                # Проверяем, активен ли токен
                await cur.execute("SELECT token FROM tokens WHERE token = %s AND is_active = 1", (token,))
                active_token = await cur.fetchone()
                if not active_token:
                    message = 'Ваш токен неактивен. Пожалуйста, авторизуйтесь заново при помощи команды /auth.'
                else:
                    message = ''
                    is_authorized = True  # Пользователь авторизован

    return message, is_authorized


def create_unique_folder_name(user_id, media_group_id=None):
    base_dir = Config.PHOTO_STORAGE_DIR
    folder_name = f"{user_id}-{media_group_id}" if media_group_id else f"{user_id}-{datetime.datetime.now().strftime('%Y%m%d%H%M%S%f')}"
    folder_path = os.path.join(base_dir, folder_name)
    os.makedirs(folder_path, exist_ok=True)
    return folder_path


def generate_unique_filename(file_name):
    _, ext = os.path.splitext(file_name)
    return f"{uuid.uuid4()}{ext}"


async def create_folders_for_user(user_id, media_group_id=None):
    folder_path = create_unique_folder_name(user_id, media_group_id)
    info_logger.info(f"Создана папка для пользователя {user_id}: {folder_path}")

    # Создаем папку "input" для сохранения фотографий
    input_folder_path = os.path.join(folder_path, "input")
    os.makedirs(input_folder_path, exist_ok=True)

    # Создаем папку "output" для сохранения результатов обработки
    output_folder_path = os.path.join(folder_path, "output")
    os.makedirs(output_folder_path, exist_ok=True)

    return input_folder_path, output_folder_path


async def save_document(document, path):
    file_name = generate_unique_filename(document.file_name)
    file_path = os.path.join(path, file_name)
    
    # Получаем объект файла асинхронно
    try:
        document_file = await document.get_file()
        # Асинхронно скачиваем файл
        await document_file.download_to_drive(custom_path=file_path)
        info_logger.info(f"Файл {file_name} сохранен в {file_path}")
    except Exception as e:
        error_logger.error(f"Ошибка при сохранении файла: {e}")
        raise e
    return file_path
