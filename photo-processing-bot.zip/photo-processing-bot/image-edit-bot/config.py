from dotenv import load_dotenv
import os

load_dotenv()

class Config:
    TOKEN = os.getenv('TOKEN')
    RABBITMQ_SERVER = os.getenv('RABBITMQ_SERVER')
    PHOTO_STORAGE_DIR = '/app/photo-storage/'

    MENU_BUTTON = {
        "UPLOAD_PHOTOS": "Загрузить фото",
        "CANCEL": "Отменить"
    }

    NUMERIC_KEYPAD = {
        "1": "1",
        "2": "2",
        "3": "3",
        "4": "4",
        "5": "5",
        "6": "6",
        "7": "7",
        "8": "8",
        "9": "9",
        "10": "10"
    }
