-- Создаем пользователя (замените 'your_password' на желаемый пароль)
CREATE USER 'imagebot'@'%' IDENTIFIED BY '13ASEmAg19';

-- Даем пользователю привилегии на все базы данных (или ограничьте по вашему усмотрению)
GRANT ALL PRIVILEGES ON *.* TO 'imagebot'@'%' WITH GRANT OPTION;

-- Создаем таблицы
USE image_processing_bot;

-- Таблица `tokens`
CREATE TABLE `tokens` (
  `token` varchar(255) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`token`)
);

-- Таблица `users`
CREATE TABLE `users` (
  `user_id` bigint NOT NULL,
  `user_name` varchar(255) DEFAULT NULL,
  `token` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `token` (`token`)
);

-- Добавляем внешний ключ (если нужно)
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`token`) REFERENCES `tokens` (`token`) ON DELETE CASCADE;

-- Добавляем начальные данные (по желанию)
INSERT INTO `tokens` (`token`, `is_active`, `expires_at`) VALUES ('example_token', 1, NULL);
