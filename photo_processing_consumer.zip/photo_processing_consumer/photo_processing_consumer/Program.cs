﻿using System.Diagnostics;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using System.Text.Json;
using System.Text;

class Program
{
    public class PhotoMessage
    {
        public string? inputFolder { get; set; }
        public string? outputFolder { get; set; }
        public string? userId { get; set; }
    }

    static void Main(string[] args)
    {
        try
        {
            string photoshopPath = @"E:/Programs/Adobe Photoshop/Adobe Photoshop 2023/Photoshop.exe";
            string jsScriptPath = @"E:/Python Projects/photo-processing-bot/js-scripts/NeuralDreamNoFace.js";

            var factory = new ConnectionFactory() { HostName = "localhost" };
            using (var connection = factory.CreateConnection())
            using (var channel = connection.CreateModel())
            {
                channel.QueueDeclare(queue: "photos_queue", durable: true, exclusive: false, autoDelete: false, arguments: null);
                channel.BasicQos(prefetchSize: 0, prefetchCount: 1, global: false);

                var consumer = new EventingBasicConsumer(channel);
                consumer.Received += (model, ea) =>
                {
                    var body = ea.Body.ToArray();
                    var message = JsonSerializer.Deserialize<PhotoMessage>(body);

                    try
                    {
                        string inputFolder = message?.inputFolder ?? string.Empty;
                        string outputFolder = message?.outputFolder ?? string.Empty;
                        string userId = message?.userId ?? string.Empty;
                        string inputFolderJs = "";
                        string outputFolderJs = "";


                        if (!string.IsNullOrEmpty(inputFolder) && !string.IsNullOrEmpty(outputFolder))
                        {
                            // Замена пути для директорий
                            inputFolderJs = inputFolder.Replace("/app/photo-storage/", @"E:/Python Projects/photo-processing-bot/photo-storage/");
                            outputFolderJs = outputFolder.Replace("/app/photo-storage/", @"E:/Python Projects/photo-processing-bot/photo-storage/");

                            Console.WriteLine($"Received input folder: {inputFolderJs}");
                            Console.WriteLine($"Received output folder: {outputFolderJs}");

                            // Logic to modify JS script based on received message
                            ModifyJSScript(jsScriptPath, inputFolderJs, outputFolderJs);

                            ProcessStartInfo startInfo = new ProcessStartInfo(photoshopPath, jsScriptPath);
                            Process.Start(startInfo);

                            MonitorOutputFolder(outputFolderJs, outputFolder, channel, ea.DeliveryTag, userId);
                        }
                        else
                        {
                            Console.WriteLine("No input folder received in the message.");
                            channel.BasicNack(deliveryTag: ea.DeliveryTag, multiple: false, requeue: true);
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"An error occurred while processing the message: {ex.Message}");
                        channel.BasicAck(deliveryTag: ea.DeliveryTag, multiple: false);
                    }
                };

                channel.BasicConsume(queue: "photos_queue", autoAck: false, consumer: consumer);

                Console.WriteLine("Waiting for messages. To exit press CTRL+C");
                Console.ReadLine();
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"An error occurred: {ex.Message}");
        }
    }

    static void ModifyJSScript(string jsScriptPath, string inputFolder, string outputFolder)
    {
        string[] content = File.ReadAllLines(jsScriptPath);

        for (int i = 0; i < Math.Min(4, content.Length); i++)
        {
            if (content[i].Contains("inputFolder"))
            {
                content[i] = $"var inputFolder = \"{inputFolder}\";";
            }
            else if (content[i].Contains("outputFolder"))
            {
                content[i] = $"var outputFolder = \"{outputFolder}\";";
            }
        }

        File.WriteAllLines(jsScriptPath, content);
    }

    static void MonitorOutputFolder(string outputFolder, string receivedOutputFolder, IModel channel, ulong deliveryTag, string userId)
    {
        try
        {
            while (true)
            {
                var doneFilePath = Path.Combine(outputFolder, "done.txt");
                var errorFilePath = Path.Combine(outputFolder, "error.txt");

                if (File.Exists(doneFilePath))
                {
                    Console.WriteLine("File 'done.txt' found in the output folder.");
                    PublishMessage(receivedOutputFolder, userId);
                    channel.BasicAck(deliveryTag: deliveryTag, multiple: false);
                    break;
                }
                else if (File.Exists(errorFilePath))
                {
                    Console.WriteLine("File 'error.txt' found in the output folder.");
                    channel.BasicAck(deliveryTag: deliveryTag, multiple: false);
                    break;
                }

                Thread.Sleep(1000);
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"An error occurred in MonitorOutputFolder: {ex.Message}");
            channel.BasicAck(deliveryTag: deliveryTag, multiple: false);
        }
    }

    static void PublishMessage(string outputFolder, string userId)
    {
        var factory = new ConnectionFactory() { HostName = "localhost" };
        using (var connection = factory.CreateConnection())
        using (var outputChannel = connection.CreateModel())
        {
            outputChannel.QueueDeclare(queue: "photos_queue_output", durable: true, exclusive: false, autoDelete: false, arguments: null);

            var message = new { outputFolder, userId };
            var messageBody = JsonSerializer.Serialize(message);
            var messageBodyBytes = Encoding.UTF8.GetBytes(messageBody);
            outputChannel.BasicPublish(exchange: "", routingKey: "photos_queue_output", basicProperties: null, body: messageBodyBytes);
        }
    }
}
